﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PanelTracking.Applications_Local.Models
{
    /// <summary>
    /// %C%
    /// </summary>
    public class %C%Class
    {
%LP%
        /// <summary>
        /// 
        /// </summary>
        public $4 $1 { get; set; }
%ELP%
    }
}